<?php
Class Conexao{
    public $con;
    function __construct()
    {
     try{
$this->con = new PDO("mysql:hostname=localhost;dbname=carteira","root","root");
      }catch(PDOException $e){
       echo "Erro ".$e;
     }   
    }
    function Conect(){
        return $this->con;
    }
 
}

?>